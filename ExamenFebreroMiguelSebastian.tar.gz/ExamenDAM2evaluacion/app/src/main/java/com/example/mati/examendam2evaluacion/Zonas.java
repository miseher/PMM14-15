package com.example.mati.examendam2evaluacion;

/**
 * Created by mati on 29/01/15.
 */
public class Zonas {

    String zona1, continente;
    int precio;

    public Zonas(String zona1,String continente,int precio){
        this.zona1 = zona1;
        this.continente = continente;
    }
    public String toString() {
        return zona1+ " "+ continente;
    }


}
