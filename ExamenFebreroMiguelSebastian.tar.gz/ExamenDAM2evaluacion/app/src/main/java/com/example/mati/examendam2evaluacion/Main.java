package com.example.mati.examendam2evaluacion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.util.ArrayList;


public class Main extends Activity {
    Zonas zona;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button botonCalculo= (Button)findViewById(R.id.buttonMain);
        final Spinner sp = (Spinner) findViewById(R.id.spinner);
        final EditText ed1 = (EditText) findViewById(R.id.editTextPaquete);
        final RadioGroup rg=(RadioGroup)findViewById(R.id.rg);
        final CheckBox cb1=(CheckBox)findViewById(R.id.checkBox1);
        final RadioButton rb1=(RadioButton)findViewById(R.id.radioButton1);
        final RadioButton rb2=(RadioButton)findViewById(R.id.radioButton2);

        final CheckBox cb2=(CheckBox)findViewById(R.id.checkBox2);




        final ArrayList<Zonas> zonas = new ArrayList<Zonas>();

       zonas.add(new Zonas("zona A: ", "Asia y oceania",30));
       zonas.add(new Zonas("zona B: ", "America y Africa",20));
       zonas.add(new Zonas("zona C: ", "Europa",10));

        //Creamos el adaptador
        ArrayAdapter<Zonas> miAdaptador = new ArrayAdapter<Zonas>(this, android.R.layout.simple_spinner_item, zonas);
        miAdaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(miAdaptador);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            public void onItemSelected(AdapterView arg0, View arg1, int position, long id) {
                zona = (Zonas) arg0.getItemAtPosition(position);
                //Toast.makeText(main.this, cliente.getNombre(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        botonCalculo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int editTextPeso = Integer.parseInt(" " + ed1.getText()); //RECOJO LO QUE HAY EN EL EDITTEXT
                String resultado="";


                Intent miIntent= new Intent(Main.this, pantalla_resultado.class);//CREO EL BUNDLE PARA PASAR A LA PANTALLA DEL RESULTADO
                Bundle miBundle=new Bundle();

                if( rg.getCheckedRadioButtonId()==R.id.radioButton1 && editTextPeso<=5){
                    resultado=" Coste final: "+(editTextPeso*1);  //INTENTO CALCULAR LAS TARIFAS DE PESO

                }
                if( rg.getCheckedRadioButtonId()==R.id.radioButton2 && (editTextPeso>6 && editTextPeso<=10)) {
                    resultado=" Coste final: "+(editTextPeso*1.5);
                }
                if( rg.getCheckedRadioButtonId()==R.id.radioButton2 && editTextPeso>10) {
                    resultado=" Coste final: "+(editTextPeso*2);
                }
                miBundle.putString("TEXTO", resultado); //DEBERIA PASAR PERO ME SALTA MENSAJE "UNFORTUNATELY THE APP STOPPED"
                miIntent.putExtras(miBundle);
                startActivity(miIntent);

            }
        });


    }



}
