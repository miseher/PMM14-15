package com.example.mati.examendam2evaluacion;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.mati.examendam2evaluacion.R;

public class pantalla_resultado extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_resultado);

        //TENDRIA QUE SALIR EL CALCULO
        final TextView textres= (TextView)findViewById(R.id.textRes);

        Bundle  miBundleRecoger = getIntent().getExtras();
        textres.setText(miBundleRecoger.getString("TEXTO"));

    }



}
